<?php
$mode_file = __DIR__ . '/../python/mode.json';

// Si no existeix, crear-lo amb valor per defecte
if (!file_exists($mode_file)) {
    file_put_contents($mode_file, json_encode(['mode' => 'Mascota']));
}

// Llegeix el mode actual
$current_data = json_decode(file_get_contents($mode_file), true);
$raw_mode = $current_data['mode'] ?? 'Mascota';
$current_mode = strtolower($raw_mode); // normalizem per fer comparació

// Canviar mode si s'ha fet POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_mode = ($current_mode === 'policia') ? 'Mascota' : 'Policia';
    file_put_contents($mode_file, json_encode(['mode' => $new_mode]));
    $raw_mode = $new_mode;
}

// Mostrar mode actual
?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Canviar Mode</title>
</head>
<body>
    <h1>Mode actual: <strong><?= htmlspecialchars($raw_mode) ?></strong></h1>

    <form method="POST">
        <button type="submit">Canvia a <?= (strtolower($raw_mode) === 'policia') ? 'Mascota' : 'Policia' ?></button>
    </form>
    <div class="tornar-menu-container">
    <a href="/index.php?opcio=home" class="boto-tornar-menu">Tornar al menú principal</a>
    </div>
</body>

</html>
