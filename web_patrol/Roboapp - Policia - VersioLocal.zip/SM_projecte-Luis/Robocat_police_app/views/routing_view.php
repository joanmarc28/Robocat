<div class="map">
  <h2>Seleccionar Ruta</h2>

  <form id="route-form">
    <label>Origen:
      <input type="text" id="origin" name="origin" required>
    </label>
    <label>Destí:
      <input type="text" id="destination" name="destination" required>
    </label>
    <button type="submit">Mostrar Ruta</button>
    <button type="button" id="save-route" disabled>Guardar Ruta</button>
    <div id="missatge"><?= $missatge ?? '' ?></div>
    <button type="button" id="set-current-location">Usar la meva ubicació com a origen</button>
    <p><small>Pots escriure o fer clic al mapa per marcar punts.</small></p>
  </form>

  <div id="map" style="height: 400px;"></div>

</div>

<div class="tornar-menu-container">
  <a href="/index.php?opcio=home" class="boto-tornar-menu">Tornar al menú principal</a>
</div>

<!-- Google Maps API -->
<script async defer
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyARNp2EGGMFsIDDH68o6WrXKPUhjs0Fghg&libraries=places&callback=initMap">
</script>

<!-- Script extern -->
<script src="/../js/script.js"></script>
