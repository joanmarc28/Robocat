<header class="app-header">
    <a href="/index.php?opcio=home" class="logo-container">
        <img src="/img/logo.PNG" alt="Logo de Robocat" class="logo">
        <h1 class="app-title">Robocat</h1>
    </a>
    <div class="user-status">
        <?php if (isset($usuari)): ?>
            <?php if (!empty($usuari['placa'])): ?>
                <span class="logged-in">👤 Agent <?= htmlspecialchars($usuari['placa']) ?> | <a href="/controllers/logout_controller.php">Sortir</a></span>
            <?php else: ?>
                <span class="logged-in">👤 Agent desconegut | <a href="/controllers/logout_controller.php">Sortir</a></span>
            <?php endif; ?>
        <?php else: ?>
            <div class="auth-links">
                <a class="login-link" href="/index.php?action=options&opcio=login">Inicia sessió</a>
                <a class="signup-link" href="/index.php?action=options&opcio=signup">Registre</a>
            </div>
        <?php endif; ?>
    </div>
</header>
