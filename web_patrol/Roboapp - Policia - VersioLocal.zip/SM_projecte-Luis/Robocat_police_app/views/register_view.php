<div class="formulari">
  <h2>Registre de Policia</h2>
  <form method="POST" action="../resources/register_resource.php">
    <input type="text" name="nom" placeholder="Nom" pattern="[a-zA-ZáéíóúÁÉÍÓÚàèòÀÈÒñÑ ]+" maxlength="30" required title="Només s'accepten lletres i espais."><br>
    <input type="text" name="cognoms" placeholder="Cognoms" maxlength="30" required title="Només s'accepten lletres i espais."><br>
    <input type="text" name="dni" placeholder="DNI" pattern="[a-zA-Z0-9]+" required title="El DNI ha de ser de tipus alfanumèric."><br>
    <input type="number" name="placa" placeholder="Número de placa" 
       required min="0001" max="9999" 
       title="Ha de ser un número de 4 xifres.">
    <input type="password" name="contrasenya" placeholder="Contrasenya" pattern="[a-zA-Z0-9]+" required title="La contrasenya ha de ser de tipus alfanumèric."><br>
    <button type="submit">Registrar</button>
  </form>

  <div id="missatge"><?= $missatge ?? '' ?></div>

  <div class="tornar-menu-container">
    <a href="/index.php?opcio=home" class="boto-tornar-menu">Torna a pàgina d'inici</a>
  </div>
  
</div>