<div class = "dblist">
    <h2>Llista d'infractors</h2>
    <table border='1'>
        <tr>
            <th>Nom</th>
            <th>DNI</th>
            <th>Matrícula</th>
            <th>Data</th>
            <th>Import</th>
            <th>Infracció</th>
        </tr>
        <?php foreach ($infractors as $i): ?>
            <tr>
                <td data-label="Nom"><span><?= htmlspecialchars($i['nom']) ?></span></td>
                <td data-label="DNI"><span><?= htmlspecialchars($i['dni']) ?></span></td>
                <td data-label="Matrícula"><span><?= htmlspecialchars($i['matricula']) ?></span></td>
                <td data-label="Data"><span><?= htmlspecialchars($i['data']) ?></span></td>
                <td data-label="Import"><span><?= htmlspecialchars($i['import']) ?> €</span></td>
                <td data-label="Infracció"><span><?= htmlspecialchars($i['infraccio']) ?></span></td>
                <td>
                    <form method="POST" style="margin:0;">
                        <input type="hidden" name="accio" value="eliminar">
                        <input type="hidden" name="dni" value="<?= htmlspecialchars($i['dni']) ?>">
                        <input type="hidden" name="data" value="<?= htmlspecialchars($i['data']) ?>">
                        <button type="submit" class="boto-eliminar">🗑️</button>
                    </form>
                </td>
            </tr>


        <?php endforeach; ?>
    </table>
</div>