<div class="menu-opcions">
    <ul>
        <li><a href="/index.php?action=options&opcio=routing"> Planificar ruta</a></li>
        <li><a href="/index.php?action=options&opcio=gemini"> Anàlisi d'imatges</a></li>
        <li><a href="/index.php?action=options&opcio=stt"> Anàlisi d'àudios</a></li>
        <li><a href="/index.php?action=options&opcio=infractors"> Base de dades d'infraccions</a></li>
        <li><a href="/index.php?action=options&opcio=afegir-infraccio"> Afegir infracció a la base de dades</a></li>
        <li><a href="/index.php?action=options&opcio=mode"> Mode de funcionament</a></li>
        
    </ul>
</div>