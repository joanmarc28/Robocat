<?php
// Determina el mode
$mode_path = __DIR__ . '/../python/mode.json';
$mode = 'policia'; // per defecte

if (file_exists($mode_path)) {
    $mode_data = json_decode(file_get_contents($mode_path), true);
    if (isset($mode_data['mode'])) {
        $mode = strtolower(trim($mode_data['mode']));
    }
}
?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Anàlisi en directe</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        video { border: 2px solid #ccc; border-radius: 8px; }
        #resultat { margin-top: 20px; }
    </style>
</head>
<body>
    <h1>📷 Càmera i detecció en directe</h1>

    <video autoplay playsinline id="webcam" width="640" height="480"></video>

    <div id="resultat">
        <h2>Resultats:</h2>

        <div id="bloc-policia" style="display: none;">
            <p><strong>Matrícules:</strong> <span id="matricules">Carregant...</span></p>
            <p><strong>Infracció:</strong> <span id="infraccio">Cap</span></p>
        </div>

        <div id="bloc-emocions" style="display: none;">
            <p><strong>Emocions:</strong> <span id="emocions">Carregant...</span></p>
            <p><strong>Resum emocional:</strong> <span id="analisi">Cap</span></p>
        </div>
    </div>

    <div class="tornar-menu-container">
        <a href="/index.php?opcio=home" class="boto-tornar-menu">Tornar al menú principal</a>
    </div>



    <script>
        const mode = "<?= $mode ?>";  // Passar mode a JS

        // Mostrar la webcam
        const video = document.getElementById('webcam');
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => { video.srcObject = stream; })
            .catch(err => { alert("No s'ha pogut accedir a la càmera: " + err); });

        // Mostrar bloc correcte segons mode
        window.addEventListener('DOMContentLoaded', () => {
            if (mode === 'policia') {
                document.getElementById('bloc-policia').style.display = 'block';
            } else {
                document.getElementById('bloc-emocions').style.display = 'block';
            }
        });

        // Captura i envia cada 5s
        setInterval(enviarFrame, 5000);

        async function enviarFrame() {
            if (video.readyState < 2) return;

            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);

            const dataURL = canvas.toDataURL('image/jpeg');

            try {
                const res = await fetch('/controllers/gemini_controller.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ imatge: dataURL })
                });

                if (!res.ok) throw new Error('Resposta HTTP no vàlida');

                const data = await res.json();

                if (mode === 'policia') {
                    document.getElementById('matricules').textContent = data.matricules?.join(', ') || 'Cap';
                    document.getElementById('infraccio').textContent = data.infraccio || 'Cap';
                } else {
                    document.getElementById('emocions').textContent = data.emocions?.join(', ') || 'Cap';
                    document.getElementById('analisi').textContent = data.analisi || 'Cap';
                }
            } catch (error) {
                console.error('Error enviant frame:', error);
            }
        }
    </script>
</body>
</html>
