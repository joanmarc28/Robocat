<div class="dblist">
    <h2>Llista de possibles infraccions</h2>
    <table border='1'>
        <tr>
            <th>Matrícula</th>
            <th>Infracció</th>
            <th>Timestamp</th>
            <th>Acció</th>
        </tr>
        <?php foreach ($infractors as $i): ?>
            <tr>
                <td data-label="Matrícula">
                    <span>
                        <?php
                            $matricula = $i['matricula'];
                            if (is_array($matricula)) {
                                echo htmlspecialchars(implode(", ", $matricula));
                                $matricula_val = $matricula[0]; // Primera matrícula per al formulari
                            } else {
                                echo htmlspecialchars($matricula);
                                $matricula_val = $matricula;
                            }
                        ?>
                    </span>
                </td>
                <td data-label="Infracció"><span><?= htmlspecialchars($i['infraccio']) ?></span></td>
                <td data-label="Timestamp"><span><?= htmlspecialchars($i['timestamp']) ?></span></td>
                <td>
                    <form method="POST" style="margin:0;">
                        <input type="hidden" name="accio" value="eliminar">
                        <input type="hidden" name="matricula" value="<?= htmlspecialchars($matricula_val) ?>">
                        <input type="hidden" name="timestamp" value="<?= htmlspecialchars($i['timestamp']) ?>">
                        <button type="submit" class="boto-eliminar" title="Eliminar infracció">🗑️</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <div class="tornar-menu-container">
        <a href="/index.php?opcio=home" class="boto-tornar-menu">Tornar al menú principal</a>
    </div>
</div>
