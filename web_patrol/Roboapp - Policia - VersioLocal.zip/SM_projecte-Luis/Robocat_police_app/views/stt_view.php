<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Analitzar àudio</title>
</head>
<body>
    <h1>Analitzar àudio local</h1>

    <form action="./index.php?action=options&opcio=stt" method="POST">
        <input type="hidden" name="audio_path" value="./audios/audio.mp3">
        <button type="submit">Analitzar</button>
    </form>
    <div class="tornar-menu-container">
    <a href="/index.php?opcio=home" class="boto-tornar-menu">Tornar al menú principal</a>
    </div>
</body>
</html>