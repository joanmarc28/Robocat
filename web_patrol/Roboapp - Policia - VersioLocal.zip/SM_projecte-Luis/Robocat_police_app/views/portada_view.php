<div class="portada">
    <div class="logo-animat">
        <img src="img/logo.PNG" alt="Logo Robocat" class="logo-img">
    </div>
    <h1 class="titol-app">Robocat</h1>
    <div class="botons">
        <a href="/resources/login_resource.php" class="boto">Inicia sessió</a>
        <a href="/resources/register_resource.php" class="boto">Registra't</a>
    </div>
</div>
