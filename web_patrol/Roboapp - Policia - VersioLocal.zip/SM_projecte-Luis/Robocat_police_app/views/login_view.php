<div class="formulari">
  <h2>Inici de Sessió</h2>
  <form method="POST" action="../index.php?action=options&opcio=login">
    <input type="text" name="id" placeholder="DNI o número de placa" required><br>
    <input type="password" name="contrasenya" placeholder="Contrasenya" required><br>
    <button type="submit">Inicia sessió</button>
  </form>

  <div id="missatge"><?= $missatge ?? '' ?></div>

  <div class="tornar-menu-container">
    <a href="/index.php?opcio=home" class="boto-tornar-menu">Accedeix a la app</a>
  </div>
</div>
