<div class="formulari">
    <h3>Afegir nou infractor</h3>
    <form action="../index.php?action=options&opcio=afegir-infraccio" method="POST">
        <input type="text" name="nom" placeholder="Nom" required>
        <input type="text" name="dni" placeholder="DNI" required>
        <input type="text" name="matricula" placeholder="Matrícula" required>
        <input type="date" name="data" required>
        <input type="text" name="infraccio" placeholder="Infracció" required>
        <input type="number" name="import" placeholder="Import (€)" required>
        <button type="submit">Afegir Infractor</button>
    </form>

    <?php if (isset($missatge_insercio)): ?>
        <div id="missatge" class="<?= $classe_missatge ?? '' ?>"><?= $missatge_insercio ?></div>
    <?php endif; ?>

    <div class="tornar-menu-container">
        <a href="/index.php?opcio=home" class="boto-tornar-menu">Tornar al menú principal</a>
    </div>
</div>