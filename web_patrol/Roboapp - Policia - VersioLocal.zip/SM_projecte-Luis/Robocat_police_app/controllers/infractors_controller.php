<?php

if (!isset($_SESSION['usuari'])) {
    include_once  __DIR__."/../resources/portada_resource.php";
    exit;
}
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accio'] ?? '') === 'eliminar') {
        $dni = $_POST['dni'] ?? '';
        $data = $_POST['data'] ?? '';

        include_once __DIR__ . '/../models/infractors_model.php';
        eliminarInfractor($dni, $data);
    }

    include_once __DIR__.'/../models/infractors_model.php';

    $infractors = obtenirInfractors();

    
    
    include __DIR__.'/../views/infractors_view.php';
?>