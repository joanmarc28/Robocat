<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// AJAX: comprovem primer
$isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';

if (!isset($_SESSION['usuari'])) {
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Usuari no autenticat']);
        exit;
    } else {
        include __DIR__ . "/../resources/home_resource.php";
        exit;
    }
}

include_once __DIR__ . '/../models/routing_model.php';

// PROCESSAR GUARDAR_RUTA


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_ruta'])) {
    $usuari = $_SESSION['usuari'] ?? 'desconegut';
    $origen = $_POST['origin'] ?? '';
    $desti = $_POST['destination'] ?? '';
    $coords_json = $_POST['coords'] ?? '[]';

    $result = guardar_ruta($usuari, $origen, $desti, $coords_json);

    if ($result['success']) {
        $missatge = "Ruta guardada correctament!";
    } else {
        $missatge = "Error guardant ruta: " . ($result['message'] ?? 'Desconegut');
    }
}


// En qualsevol altre cas: mostra la vista
include __DIR__ . '/../views/routing_view.php';
