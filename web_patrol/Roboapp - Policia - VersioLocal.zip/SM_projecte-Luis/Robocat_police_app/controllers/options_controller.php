<?php
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
if (!isset($_SESSION['usuari'])) {
    include_once  __DIR__."/../resources/portada_resource.php";
    exit;
}
    include __DIR__.'/../views/home_view.php';
?>