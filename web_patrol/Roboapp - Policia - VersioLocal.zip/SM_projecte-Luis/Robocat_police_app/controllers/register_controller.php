<?php
include_once __DIR__ . '/../models/register_model.php';

$missatge = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"] ?? '';
    $cognoms = $_POST["cognoms"] ?? '';
    $dni = $_POST["dni"] ?? '';
    $placa = $_POST["placa"] ?? '';
    $contrasenya = $_POST["contrasenya"] ?? '';

    $estat = registrar_policia($nom, $cognoms, $dni, $placa, $contrasenya);

    // Ara $estat pot ser un array amb 'status' i 'detall', o una cadena 'ok'
    if (is_array($estat)) {
        if (isset($estat['status']) && $estat['status'] === 'ok') {
            $missatge = "<div class='success'>Usuari registrat correctament!</div>";
        } else {
            $detall = $estat['detall'] ?? 'Error desconegut';
            // Escapa per seguretat abans de mostrar
            $missatge = "<div class='error'>Error en el registre: " . htmlspecialchars($detall) . "</div>";
        }
    } else if ($estat === "ok") {
        $missatge = "<div class='success'>Usuari registrat correctament!</div>";
    } else {
        // Per si només arriba una cadena diferent
        $missatge = "<div class='error'>Error en el registre: " . htmlspecialchars($estat) . "</div>";
    }
}

include __DIR__ . '/../views/register_view.php';
