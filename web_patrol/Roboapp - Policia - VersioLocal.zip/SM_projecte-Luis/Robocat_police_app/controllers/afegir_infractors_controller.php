<?php
if (!isset($_SESSION['usuari'])) {
    include_once  __DIR__."/../resources/portada_resource.php";
    exit;
}

$missatge_insercio = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include_once __DIR__ . '/../models/infractors_model.php';

    $dades = [
        "nom" => $_POST["nom"] ?? "",
        "dni" => $_POST["dni"] ?? "",
        "matricula" => $_POST["matricula"] ?? "",
        "data" => $_POST["data"] ?? "",
        "infraccio" => $_POST["infraccio"] ?? "",
        "import" => floatval($_POST["import"] ?? 0)
    ];

    $resultat = afegirInfractor($dades);

    if ($resultat && isset($resultat['status']) && $resultat['status'] === 'ok') {
    $missatge_insercio = 'Infractor afegit correctament.';
    $classe_missatge = 'success';
    } else {
        $error_msg = $resultat['missatge'] ?? 'Error desconegut.';
        $missatge_insercio = 'Error en afegir infractor: ' . $error_msg;
        $classe_missatge = 'error';
    }
}

include __DIR__ . '/../views/afegir_infractors_view.php';
?>
