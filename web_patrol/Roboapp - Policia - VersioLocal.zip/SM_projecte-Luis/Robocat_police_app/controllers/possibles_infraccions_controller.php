<?php
if (!isset($_SESSION['usuari'])) {
    include_once  __DIR__."/../resources/portada_resource.php";
    exit;
}
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accio'] ?? '') === 'eliminar') {
        $matricula = $_POST['matricula'] ?? '';
        $timestamp = $_POST['timestamp'] ?? '';

        include_once __DIR__ . '/../models/infractors_model.php';
        eliminarPossibleInfraccio($matricula, $timestamp);
    }

    include_once __DIR__.'/../models/infractors_model.php';

    $infractors = obtenirPossiblesInfractors();

    
    
    include __DIR__.'/../views/possibles_infractors_view.php';
?>