<?php
include_once __DIR__.'/../models/login_model.php';

$missatge = "";

if (isset($_SESSION['usuari'])) {
    include __DIR__."/../resources/portada_resource.php";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"] ?? '';
    $contrasenya = $_POST["contrasenya"] ?? '';

    $estat = verificar_login($id, $contrasenya);

    if ($estat['status'] === "ok") {
        $_SESSION['usuari'] = [
            'id' => $id,
            'nom' => $estat['nom'] ?? '',
            'cognoms' => $estat['cognoms'] ?? '',
            'placa' => $estat['placa'] ?? '',
            'dni' => $estat['dni'] ?? '',
        ];
        $missatge = "<div class='success'>Sessió iniciada correctament!</div>";
        #include_once __DIR__."/../resources/home_resource.php"; 
        #exit;
    
    } else {
        $missatge = "<div class='error'>Credencials incorrectes.</div>";
    }

}

include __DIR__.'/../views/login_view.php';
