<?php
    include_once __DIR__.'/../models/stt_model.php';
    
if (!isset($_SESSION['usuari'])) {
    include_once  __DIR__."/../resources/portada_resource.php";
    exit;
}
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['audio_path'])) {
        $ruta_audio = $_POST['audio_path'];
        
        if (!file_exists($ruta_audio)) {
            echo "<p style='color:red;'>Fitxer no trobat: $ruta_audio</p>";
            exit;
        }

        $resultat = analitzar_audio_stt($ruta_audio);

        if ($resultat && $resultat['status'] === "trobada") {
            echo "<h2>Transcripció:</h2>";
            echo "<p><em>" . htmlspecialchars($resultat['transcripcio']) . "</em></p>";

            echo "<h3>Infracció trobada:</h3>";
            $dades = $resultat['dades'];

            echo "<ul style='list-style-type: none; padding: 0;'>";
            echo "<li><strong>Nom:</strong> " . htmlspecialchars($dades['nom']) . "</li>";
            echo "<li><strong>DNI:</strong> " . htmlspecialchars($dades['dni']) . "</li>";
            echo "<li><strong>Matricula:</strong> " . htmlspecialchars($dades['matricula']) . "</li>";
            echo "<li><strong>Import:</strong> " . htmlspecialchars($dades['import']) . " €</li>";
            echo "<li><strong>Infracció:</strong> " . htmlspecialchars($dades['infraccio']) . "</li>";
            echo "<li><strong>Data:</strong> " . htmlspecialchars($dades['data']) . "</li>";
            echo "</ul>";

        } else {
            echo "<p>No s'han trobat multes o no s'ha reconegut cap nom conegut.</p>";
            if ($resultat) {
                echo "<p><em>Transcripció: {$resultat['transcripcio']}</em></p>";
            }
        }
    } else {
        
    }
    include __DIR__.'/../views/stt_view.php';
?>