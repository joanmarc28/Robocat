<?php


//Original path de carpetas editables
$_MODE_PATH = __DIR__ . '/python/mode.json';
$_RESULT_PATH = __DIR__ . '/python/resultat.json';

include_once __DIR__ . '/../models/gemini_model.php';
include_once __DIR__ . '/../models/gemini_model_emocions.php';

if (!isset($_SESSION['usuari'])) {
    include_once  __DIR__."/../resources/portada_resource.php";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {



    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (empty($data['imatge'])) {
        http_response_code(400);
        echo json_encode(['error' => 'No s\'ha enviat cap imatge']);
        exit;
    }

    $imatge_base64 = preg_replace('#^data:image/\w+;base64,#i', '', $data['imatge']);
    $imatge_binari = base64_decode($imatge_base64);

    if ($imatge_binari === false) {
        http_response_code(400);
        echo json_encode(['error' => 'Imatge no vàlida']);
        exit;
    }

    $tmp_path = sys_get_temp_dir() . '/frame.jpg';
    file_put_contents($tmp_path, $imatge_binari);

    $mode_path = '/tmp/mode.json';
    #$mode_path = __DIR__ . '/../python/mode.json';

    $mode = 'Policia'; 

    if (file_exists($mode_path)) {
        $mode_data = json_decode(file_get_contents($mode_path), true);
        if (isset($mode_data['mode'])) {
            $mode = strtolower(trim($mode_data['mode']));
        }
    }

    if ($mode === 'policia') {
        $resultat = analitzar_imatge($tmp_path);
    } else {
        $resultat = analitzar_emocions($tmp_path);
    }

    header('Content-Type: application/json');
    echo json_encode($resultat);
    exit;
}

if (isset($_GET['api'])) {
    // Opcional: retorna el resultat guardat
    #$ruta_resultat = __DIR__ . '/../python/resultat.json';

    $ruta_resultat =  '/tmp/resultat.json';

    $resultat = obtenir_resultat_analisi($ruta_resultat);
    header('Content-Type: application/json');
    echo json_encode($resultat);
    exit;
}

include __DIR__ . '/../views/gemini_view.php';
?>
