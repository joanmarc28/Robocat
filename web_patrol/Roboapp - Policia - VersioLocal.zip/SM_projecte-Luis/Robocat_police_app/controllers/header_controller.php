<?php 
if (isset($_SESSION['usuari'])) {
        $usuari = $_SESSION['usuari'] ?? null;
    include __DIR__.'/../views/header_view.php';

}
    //session_start();


?>