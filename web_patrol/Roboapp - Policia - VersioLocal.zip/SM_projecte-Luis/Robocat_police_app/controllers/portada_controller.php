<?php 

if (isset($_SESSION['usuari'])) {
    include __DIR__."/../resources/home_resource.php";
    exit;
}

include __DIR__ . '/../views/portada_view.php'; ?>