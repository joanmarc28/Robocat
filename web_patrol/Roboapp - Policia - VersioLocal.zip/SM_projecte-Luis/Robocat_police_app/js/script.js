let map;
let directionsService;
let directionsRenderer;
let geocoder;
let originMarker = null;
let destinationMarker = null;
let clickCount = 0;
let userMarker = null;
let userLocation = null;
let currentRouteCoords = [];

// Quan carregui el script, deshabilitem el botó guardar ruta
document.addEventListener('DOMContentLoaded', () => {
  const saveBtn = document.getElementById("save-route");
  if (saveBtn) saveBtn.disabled = true;
});

function initMap() {
  const barcelona = { lat: 41.3851, lng: 2.1734 };

  map = new google.maps.Map(document.getElementById("map"), {
    center: barcelona,
    zoom: 13,
  });

  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer();
  directionsRenderer.setMap(map);
  geocoder = new google.maps.Geocoder();

  const originInput = document.getElementById("origin");
  const destinationInput = document.getElementById("destination");
  new google.maps.places.Autocomplete(originInput);
  new google.maps.places.Autocomplete(destinationInput);

  if (navigator.geolocation) {
    navigator.geolocation.watchPosition(
      (position) => {
        userLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };

        if (!userMarker) {
          userMarker = new google.maps.Marker({
            position: userLocation,
            map: map,
            title: "La meva ubicació",
            icon: {
              path: google.maps.SymbolPath.CIRCLE,
              scale: 8,
              fillColor: '#4285F4',
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 2,
            },
          });
          map.setCenter(userLocation);
        } else {
          userMarker.setPosition(userLocation);
        }
      },
      (error) => {
        console.warn("No s'ha pogut obtenir la ubicació:", error.message);
      }
    );
  }

  map.addListener("click", (event) => {
    const location = event.latLng;
    geocoder.geocode({ location: location }, (results, status) => {
      if (status === "OK" && results[0]) {
        const address = results[0].formatted_address;
        if (clickCount === 0) {
          if (originMarker) originMarker.setMap(null);
          originMarker = new google.maps.Marker({
            position: location,
            map: map,
            label: "A",
          });
          originInput.value = address;
          clickCount = 1;
        } else {
          if (destinationMarker) destinationMarker.setMap(null);
          destinationMarker = new google.maps.Marker({
            position: location,
            map: map,
            label: "B",
          });
          destinationInput.value = address;
          clickCount = 0;
        }
      } else {
        alert("No s'ha pogut obtenir l'adreça: " + status);
      }
    });
  });
}

// Formulari Mostrar Ruta
document.getElementById("route-form").addEventListener("submit", function (e) {
  e.preventDefault();

  const origin = document.getElementById("origin").value;
  const destination = document.getElementById("destination").value;

  directionsService.route(
    {
      origin: origin,
      destination: destination,
      travelMode: google.maps.TravelMode.WALKING,
    },
    (response, status) => {
      if (status === "OK") {
        directionsRenderer.setDirections(response);

        currentRouteCoords = [];
        const legs = response.routes[0].legs;
        for (let i = 0; i < legs.length; i++) {
          const steps = legs[i].steps;
          for (let j = 0; j < steps.length; j++) {
            const path = steps[j].path;
            for (let k = 0; k < path.length; k++) {
              currentRouteCoords.push({
                lat: path[k].lat(),
                lng: path[k].lng(),
              });
            }
          }
        }

        document.getElementById("save-route").disabled = false;
      } else {
        alert("Error calculant ruta: " + status);
      }
    }
  );
});

// Botó Guardar Ruta
document.getElementById("save-route").addEventListener("click", () => {
  if (currentRouteCoords.length === 0) {
    alert("No hi ha cap ruta per guardar");
    return;
  }

  const origin = document.getElementById("origin").value;
  const destination = document.getElementById("destination").value;

  const formData = new FormData();
  formData.append('guardar_ruta', '1');
  formData.append('origin', origin);
  formData.append('destination', destination);
  formData.append('coords', JSON.stringify(currentRouteCoords));

  fetch('../controllers/routing_controller.php', {
    method: 'POST',
    body: formData,
  })
  .then(response => response.text())
  .then(text => {
    console.log('Resposta del servidor:', text);

    const missatgeDiv = document.getElementById("missatge");
    missatgeDiv.textContent = 'Ruta guardada correctament!';
    missatgeDiv.style.color = 'green';
    document.getElementById("save-route").disabled = true;
  })
  .catch(err => {
    alert('Error en la comunicació: ' + err);
  });
});
