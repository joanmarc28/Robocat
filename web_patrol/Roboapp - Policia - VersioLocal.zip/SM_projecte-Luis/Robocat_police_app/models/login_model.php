<?php

function verificar_login($id, $contrasenya) {
    $data = [
        "id" => $id,
        "contrasenya" => $contrasenya
    ];

    $script_path = __DIR__ . '/../python/login.py';

    if (!file_exists($script_path)) {
        error_log("Error: No s'ha trobat el fitxer Python a $script_path");
        return ['status' => 'error'];
    }
    $json_string = json_encode($data, JSON_UNESCAPED_UNICODE);
    error_log("JSON enviat al Python: " . $json_string);

    $json_string = str_replace('"', '\"', $json_string);
    $json_escaped = '"' . $json_string . '"';
    error_log("JSON escapçat per shell: " . $json_escaped);

    $python_path = "python";

    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' ' . $json_escaped;
    error_log("Comanda a executar: " . $cmd);
    $output = shell_exec($cmd . " 2>&1");

    
    if ($output === null) {
        error_log("Error: La comanda no ha retornat cap resultat.");
        return ['status' => 'error'];
    }

    //$res = json_decode($output, true);

    // Encuentra todos los bloques entre llaves
    preg_match_all('/\{.*?\}/', $output, $matches);

    if (!empty($matches[0])) {
        // Toma el último match (el segundo bloque JSON)
        $jsonString = end($matches[0]);

        // Intenta decodificarlo
        $res = json_decode($jsonString, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            #echo "✅ JSON válido extraído:\n";
            #print_r($res);
        } else {
            echo "❌ Error al decodificar JSON: " . json_last_error_msg();
        }
    } else {
        echo "⚠️ No se encontraron bloques JSON.";
    }
    
    if ($res === null && json_last_error() !== JSON_ERROR_NONE) {
        var_dump(2);
        error_log("Error: JSON invàlid retornat pel script Python.");
        error_log("Sortida rebuda: $output");
        return ['status' => 'error'];
    }

    if (!isset($res['status'])) {
        var_dump(3);
        error_log("Error: No s'ha trobat la clau 'status' en la resposta.");
        error_log("Resposta completa: " . print_r($res, true));
        return ['status' => 'error'];
    }

    error_log("Resposta del Python: " . print_r($res, true));
    error_log("Estat obtingut: " . $res['status']);

    return $res;
}

?>

