<?php

function analitzar_emocions(string $ruta_imatge): array {
    $script_path = __DIR__ . '/../python/emocions.py';
   # $comanda = escapeshellcmd("python $script_path $ruta_imatge");

    $python_path = "python";
    $comanda = $python_path . ' ' . escapeshellarg($script_path) . ' ' . $ruta_imatge;
    
    $output = shell_exec($comanda . " 2>&1");

    error_log("Sortida del Python: " . $output);
    
    if (!file_exists($script_path)) {
        error_log("Error: No s'ha trobat el fitxer Python a $script_path");
        return ['error'];
    }
    if (!$output) {
        return ['emocions' => [], 'resum' => 'Error processant la imatge'];
    }

    $ruta_resultat = '/tmp/resultat.json';

    if (!file_exists($ruta_resultat)) {
        return ['emocions' => [], 'resum' => 'No s\'ha trobat el fitxer de resultat'];
    }

    $json_str = file_get_contents($ruta_resultat);
    $primera_passada = json_decode($json_str, true);

    if (is_string($primera_passada)) {
        $json = json_decode($primera_passada, true);
    } else {
        $json = $primera_passada;
    }

    if (!$json) {
        return ['emocions' => [], 'resum' => 'Resposta no vàlida del model'];
    }

    // Neteja i normalització de claus (si venen amb accents, per exemple)
    if (isset($json['emocions_detectades'])) {
        $json['emocions'] = $json['emocions_detectades'];
        unset($json['emocions_detectades']);
    }
    if (isset($json['resum_emocional'])) {
        $json['resum'] = $json['resum_emocional'];
        unset($json['resum_emocional']);
    }

    return $json;
}

function obtenir_resultat_emocions($fitxer_json) {
    if (!file_exists($fitxer_json)) {
        return null;
    }

    $json = file_get_contents($fitxer_json);
    $dades = json_decode($json, true);

    return $dades ?: null;
}
?>