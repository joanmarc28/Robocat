<?php
function obtenirInfractors() {
    $script_path = __DIR__ . '/../python/infractors.py';
    $python_path = "python";
    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' 2>&1';
    
    $sortida = shell_exec($cmd);

    error_log("Sortida del script Python: " . $sortida);

    if ($sortida === null || trim($sortida) === '') {
        error_log("Error: la sortida està buida o null.");
        return [];
    }

    $resultat = json_decode($sortida, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("Error JSON: " . json_last_error_msg());
        error_log("Sortida rebuda: " . $sortida);
        return [];
    }

    return $resultat;
}


function obtenirPossiblesInfractors() {
    $script_path = __DIR__ . '/../python/possiblesInfractors.py';
    $python_path = "python";
    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' 2>&1';
    
    $sortida = shell_exec($cmd);

    error_log("Sortida del script Python: " . $sortida);

    if ($sortida === null || trim($sortida) === '') {
        error_log("Error: la sortida està buida o null.");
        return [];
    }

    $resultat = json_decode($sortida, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("Error JSON: " . json_last_error_msg());
        error_log("Sortida rebuda: " . $sortida);
        return [];
    }

    return $resultat;
}

function afegirInfractor($dades) {
    $script_path = __DIR__ . '/../python/afegir_infractors.py';
    if (!file_exists($script_path)) return 'Fitxer Python no trobat';

    $json_string = json_encode($dades, JSON_UNESCAPED_UNICODE);
    $escaped_json = '"' . str_replace('"', '\"', $json_string) . '"';

    $python_path = "python";
    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' ' . $escaped_json;
    error_log("COMANDA a executar: " . $cmd);

    $output = shell_exec($cmd . " 2>&1");
    if ($output === null) return "Cap resposta del script Python";

    // Pots fer que el .py torni JSON com {"status": "ok"} o {"status": "error", "missatge": "..."}
    $res = json_decode($output, true);
    if (!$res || !isset($res['status'])) return "Resposta invàlida: $output";

    return $res;
}

function eliminarInfractor($dni, $data) {
    $script_path = __DIR__ . '/../python/eliminar_infractors.py';
    if (!file_exists($script_path)) return false;

    $dades = ["dni" => $dni, "data" => $data];
    $json_string = json_encode($dades, JSON_UNESCAPED_UNICODE);
    $escaped_json = '"' . str_replace('"', '\"', $json_string) . '"';

    $cmd = "python " . escapeshellarg($script_path) . " " . $escaped_json;
    $output = shell_exec($cmd . " 2>&1");

    $res = json_decode($output, true);
    return $res && isset($res['status']) && $res['status'] === 'ok';
}

function eliminarPossibleInfraccio($matricula, $timestamp) {
    $script_path = __DIR__ . '/../python/eliminar_possibles_infraccions.py';
    if (!file_exists($script_path)) return false;

    $dades = ["matricula" => $matricula, "timestamp" => $timestamp];
    $json_string = json_encode($dades, JSON_UNESCAPED_UNICODE);
    $escaped_json = '"' . str_replace('"', '\"', $json_string) . '"';

    $cmd = "python " . escapeshellarg($script_path) . " " . $escaped_json;
    $output = shell_exec($cmd . " 2>&1");

    $res = json_decode($output, true);
    return $res && isset($res['status']) && $res['status'] === 'ok';
}



?>
