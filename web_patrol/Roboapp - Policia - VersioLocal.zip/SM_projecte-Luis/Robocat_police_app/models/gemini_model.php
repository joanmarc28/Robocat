<?php

    function analitzar_imatge(string $ruta_imatge): array {

        $script_path = __DIR__ . '/../python/gemini.py';
        $comanda = escapeshellcmd("python $script_path $ruta_imatge");
        
        $output = shell_exec($comanda . " 2>&1");
    
        error_log("Sortida del Python: " . $output);
        if (!file_exists($script_path)) {
            error_log("Error: No s'ha trobat el fitxer Python a $script_path");
            return ['error'];
        }
        if (!$output) {
            return ['matricules' => [], 'infraccio' => 'Error processant la imatge'];
        }
        $ruta_resultat = '/tmp/resultat.json';

        $json_str = file_get_contents($ruta_resultat);
        $primera_passada = json_decode($json_str, true);  // Decodifica la cadena JSON escapada
        if (is_string($primera_passada)) {
            $json = json_decode($primera_passada, true);  // Decodifica la cadena real
        } else {
            $json = $primera_passada;
        }

        if (!$json) {
            return ['matricules' => [], 'infraccio' => 'Resposta no vàlida del model'];
        }
        if ($json) {
            // Canviar les claus per les que esperes
            if (isset($json['matrícules'])) {
                $json['matricules'] = $json['matrícules'];
                unset($json['matrícules']);
            }
            if (isset($json['infracció'])) {
                $json['infraccio'] = $json['infracció'];
                unset($json['infracció']);
            }
        }

        if (isset($json['infraccio'])) {
            $infraccio = strtolower(trim($json['infraccio']));
            if (
                str_starts_with($infraccio, 'si') ||
                str_starts_with($infraccio, 'possible') ||
                str_starts_with($infraccio, 'possiblement')
            ) {
                $script_bd = __DIR__ . '/../python/gemini_bd.py';
                if (file_exists($script_bd)) {
                    $comanda_bd = escapeshellcmd("python $script_bd");
                    shell_exec($comanda_bd . " 2>&1");
                    error_log("Crida a guarda_bd.py feta.");
                } else {
                    error_log("No s'ha trobat el script per guardar a BD: $script_bd");
                }
            }
        }

        return $json;
        }

        function obtenir_resultat_analisi($fitxer_json) {
        if (!file_exists($fitxer_json)) {
            return null;
        }

        $json = file_get_contents($fitxer_json);
        $dades = json_decode($json, true);

        return $dades ?: null;
}
?>