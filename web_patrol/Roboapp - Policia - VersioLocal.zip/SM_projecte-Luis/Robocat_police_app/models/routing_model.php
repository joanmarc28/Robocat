<?php

function guardar_ruta($usuari, $origen, $desti, $coords_json) {
    error_log("guardar_ruta: inici");

    $coords = json_decode($coords_json, true);
    if ($coords === null) {
        error_log("Coords JSON invàlid: $coords_json");
        return ['status' => 'error', 'detall' => 'Coords JSON invàlid'];
    }

    $data = [
        "usuari" => $usuari,
        "origen" => $origen,
        "desti" => $desti,
        "coords" => $coords
    ];

    $script_path = __DIR__ . '/../python/guardar_ruta.py';
    if (!file_exists($script_path)) {
        error_log("Fitxer Python no trobat: $script_path");
        return ['status' => 'error', 'detall' => 'Fitxer Python no trobat'];
    }

    $python_path = "python";

    /*$json_string = json_encode($data, JSON_UNESCAPED_UNICODE);
    $escaped_json = escapeshellarg($json_string);
    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' ' . $escaped_json;
    error_log("COMANDA a executar: " . $cmd);

    $output = shell_exec($cmd . " 2>&1");



    if ($output === null) {
        error_log("Cap resposta del script Python");
        return ['status' => 'error', 'detall' => "Cap resposta del script Python"];
    }

    error_log("Sortida script Python: " . $output);

    $res = json_decode($output, true);
    if (!$res || !isset($res['status'])) {
        error_log("Resposta invàlida del script Python: $output");
        return ['status' => 'error', 'detall' => "Resposta invàlida: $output"];
    }

    error_log("guardar_ruta: finalitzat amb èxit");
    return $res;*/

    $json_string = json_encode($data, JSON_UNESCAPED_UNICODE);
    $cmd = "$python_path " . escapeshellarg($script_path);
    $descriptorspec = [
        0 => ["pipe", "r"], // stdin
        1 => ["pipe", "w"], // stdout
        2 => ["pipe", "w"]  // stderr
    ];

    $process = proc_open($cmd, $descriptorspec, $pipes);

    if (is_resource($process)) {
        fwrite($pipes[0], $json_string);
        fclose($pipes[0]);

        $output = stream_get_contents($pipes[1]);
        fclose($pipes[1]);

        $error_output = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $return_value = proc_close($process);

        if ($return_value !== 0) {
            error_log("Error execució Python: $error_output");
            return ['status' => 'error', 'detall' => $error_output];
        }

        error_log("Sortida script Python: $output");

        $res = json_decode($output, true);
        if (!$res || !isset($res['status'])) {
            return ['status' => 'error', 'detall' => 'Resposta invàlida del script Python'];
        }

        return $res;
}

}
?>
