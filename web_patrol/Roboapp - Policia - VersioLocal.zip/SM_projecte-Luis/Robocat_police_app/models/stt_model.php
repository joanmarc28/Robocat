<?php
function analitzar_audio_stt($ruta_audio) {
    $data = array("audio_path" => $ruta_audio);

    $script_path = __DIR__ . '/../python/stt.py';
    if (!file_exists($script_path)) {
        error_log("No s'ha trobat el fitxer Python: $script_path");
        return null;
    }

    $json_string = json_encode($data, JSON_UNESCAPED_UNICODE);
    $json_escaped = '"' . str_replace('"', '\"', $json_string) . '"';

    $python_path = "python"; 
    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' ' . $json_escaped;

    $output = shell_exec($cmd . " 2>&1");
    error_log("Sortida: $output");
    if ($output === null) {
        error_log("Error: no s'ha rebut cap sortida del script Python.");
        return null;
    }

    $resultat = json_decode($output, true);
    if ($resultat === null) {
        error_log("Error: JSON invàlid rebut del script Python.");
        error_log("Sortida: " . $output);
        return null;
    }

    return $resultat;
}
?>