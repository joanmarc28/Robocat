<?php

function registrar_policia($nom, $cognoms, $dni, $placa, $contrasenya) {
    $data = [
        "nom" => $nom,
        "cognoms" => $cognoms,
        "dni" => $dni,
        "placa" => (int)$placa,
        "contrasenya" => password_hash($contrasenya, PASSWORD_BCRYPT)
    ];

    $script_path = __DIR__ . '/../python/register.py';
    if (!file_exists($script_path)) return 'Fitxer Python no trobat';

    $json_string = json_encode($data, JSON_UNESCAPED_UNICODE);
    $escaped_json = '"' . str_replace('"', '\"', $json_string) . '"';

    $python_path = "python";
    $cmd = $python_path . ' ' . escapeshellarg($script_path) . ' ' . $escaped_json;
    error_log("COMANDA a executar: " . $cmd);

    $output = shell_exec($cmd . " 2>&1");
    if ($output === null) return "Cap resposta del script Python";

    $res = json_decode($output, true);
    if (!$res || !isset($res['status'])) return "Resposta invàlida: $output";

    return $res;
}
