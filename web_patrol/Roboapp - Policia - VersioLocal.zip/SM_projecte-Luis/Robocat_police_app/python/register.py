import sys
import json
import os
from google.cloud import firestore
from google.oauth2 import service_account

import warnings
warnings.filterwarnings("ignore", category=UserWarning)

args = json.loads(sys.argv[1])

nom = args["nom"]
cognoms = args["cognoms"]
dni = args["dni"]
placa = int(args["placa"])
contrasenya = args["contrasenya"]

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")

credentials = service_account.Credentials.from_service_account_file(key_path)
db = firestore.Client(credentials=credentials)

try:
    users_ref = db.collection(u'users')

    # Comprovem si ja existeix la placa
    query = users_ref.where(u'placa', u'==', placa).stream()

    placa_duplicada = False
    for user_doc in query:
        placa_duplicada = True
        break

    if placa_duplicada:
        print(json.dumps({"status": "error", "detall": "Número de placa ja registrat"}))
    else:
        # Comprovem si ja existeix el DNI (ja ho tens)
        doc_ref = users_ref.document(dni)
        doc = doc_ref.get()

        if doc.exists:
            print(json.dumps({"status": "error", "detall": "DNI ja registrat"}))
        else:
            doc_ref.set({
                u'Nom': nom,
                u'Cognoms': cognoms,
                u'DNI': dni,
                u'placa': placa,
                u'Contrasenya': contrasenya
            })
            print(json.dumps({"status": "ok"}))

except Exception as e:
    print(json.dumps({"status": "error", "detall": str(e)}))


