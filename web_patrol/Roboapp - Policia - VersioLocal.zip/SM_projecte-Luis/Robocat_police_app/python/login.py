import sys
import json
import os
import warnings
import bcrypt


warnings.filterwarnings("ignore", category=UserWarning)

from google.cloud import firestore
from google.oauth2 import service_account

args = json.loads(sys.argv[1])

id_entrada = args["id"]
contrasenya_entrada = args["contrasenya"].encode('utf-8')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")

credentials = service_account.Credentials.from_service_account_file(key_path)
db = firestore.Client(credentials=credentials)

def check_password(stored_hash, password):
    return bcrypt.checkpw(password, stored_hash.encode('utf-8'))

status = "error"
user_data = None

try:
    # 1. Buscar document per id (DNI)
    doc_ref = db.collection(u'users').document(id_entrada)
    doc = doc_ref.get()

    if doc.exists:
        user_data = doc.to_dict()
        print(f"Usuari trobat per DNI: {user_data}", file=sys.stderr)
    else:
        # 2. Buscar per placa, només si és número
        try:
            placa_int = int(id_entrada)
            query = db.collection(u'users').where(u'placa', u'==', placa_int).stream()
            for doc_placa in query:
                user_data = doc_placa.to_dict()
                print(f"Usuari trobat per placa: {user_data}", file=sys.stderr)
                break
        except ValueError:
            print(f"Id entrada no és número per buscar placa: {id_entrada}", file=sys.stderr)

    if user_data:
        hash_contrasenya = user_data.get("Contrasenya")
        if hash_contrasenya:
            if check_password(hash_contrasenya, contrasenya_entrada):
                status = "ok"
                print("Contrasenya correcta", file=sys.stderr)
            else:
                print("Contrasenya incorrecta", file=sys.stderr)
        else:
            print("No hi ha hash de contrasenya", file=sys.stderr)
    else:
        print("Usuari no trobat", file=sys.stderr)

except Exception as e:
    print(f"Error: {str(e)}", file=sys.stderr)
    status = "error"

result = {"status": status}

if status == "ok" and user_data:
    result.update({
        "nom": user_data.get("Nom", ""),
        "cognoms": user_data.get("Cognoms", ""),
        "placa": user_data.get("placa", ""),
        "dni": user_data.get("DNI", "")
    })

print(json.dumps(result))
