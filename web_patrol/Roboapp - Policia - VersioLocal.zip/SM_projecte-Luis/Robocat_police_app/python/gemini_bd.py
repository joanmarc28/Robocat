import json
import os
from datetime import datetime, timezone
from google.cloud import firestore
from google.oauth2 import service_account


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")
credentials = service_account.Credentials.from_service_account_file(key_path)
db = firestore.Client(credentials=credentials)


resultat_path = "/tmp/resultat.json"
#resultat_path = os.path.join(os.path.dirname(__file__), 'resultat.json')

try:
    with open(resultat_path, 'r', encoding='utf-8') as f:
        primer_nivell = json.load(f)

    dades = json.loads(primer_nivell) if isinstance(primer_nivell, str) else primer_nivell

    if 'matricules' not in dades or 'infraccio' not in dades:
        raise ValueError("Falten claus requerides: 'matricules' o 'infraccio'")

    col_ref = db.collection('possibles_infractors')
    duplicada = False

    # Comprovar si alguna de les matrícules ja existeix
    for matricula in dades['matricules']:
        query = col_ref.where('matricules', 'array_contains', matricula).limit(1).stream()
        if any(query):
            duplicada = True
            break

    if duplicada:
        print(json.dumps({"status": "duplicada", "missatge": "Matrícula ja existent a possibles_infractors"}))
    else:
        # Afegir timestamp i guardar nou document
        dades['timestamp'] = datetime.now(timezone.utc).isoformat()
        doc_ref = col_ref.document()
        doc_ref.set(dades)
        print(json.dumps({"status": "ok"}))

except Exception as e:
    print(json.dumps({"status": "error", "missatge": str(e)}))
