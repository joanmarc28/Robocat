import sys
import json
import os
from google.cloud import firestore
from google.oauth2 import service_account

try:
    # Llegeix JSON per stdin
    data_json = sys.stdin.read()
    args = json.loads(data_json)
except Exception as e:
    print(json.dumps({"status": "error", "detall": f"JSON invàlid o error lectura stdin: {str(e)}"}))
    sys.exit(1)

usuari = args.get("usuari")
origen = args.get("origen")
desti = args.get("desti")
coords = args.get("coords")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")

credentials = service_account.Credentials.from_service_account_file(key_path)
db = firestore.Client(credentials=credentials)

try:
    rutas_ref = db.collection(u'Rutes')

    doc_ref = rutas_ref.document()
    doc_ref.set({
        u'usuari': usuari,
        u'origen': origen,
        u'desti': desti,
        u'coords': coords
    })
    print(json.dumps({"success": True}))

except Exception as e:
    print(json.dumps({"status": "error", "detall": str(e)}))
