import sys
import json
import os
import re
from google.cloud import speech_v1p1beta1 as speech
from google.oauth2 import service_account
from google.cloud import firestore


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
stt_key_path = os.path.join(BASE_DIR,"..", "keys", "STT", "projecte-sm-f36f41345a56.json")
db_key_path = os.path.join(BASE_DIR,"..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")


args = json.loads(sys.argv[1])
file_path = args["audio_path"]

stt_credentials = service_account.Credentials.from_service_account_file(stt_key_path)
client = speech.SpeechClient(credentials=stt_credentials)

with open(file_path, "rb") as f:
    content = f.read()

audio = speech.RecognitionAudio(content=content)
config = speech.RecognitionConfig(
    encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
    sample_rate_hertz=16000,
    language_code="es-ES",
    enable_automatic_punctuation=True
)

response = client.recognize(config=config, audio=audio)
transcript = " ".join([result.alternatives[0].transcript for result in response.results])


net_transcript = re.sub(r'[^A-Z0-9]', '', transcript.upper())  # ex: "0 9 8 7 CV" → "0987CV"


db_credentials = service_account.Credentials.from_service_account_file(db_key_path)
db = firestore.Client(credentials=db_credentials)
col_ref = db.collection('infractors')

coincidencia = None

# Buscar coincidència parcial basada en prefix de 5 caràcters
for doc in col_ref.stream():
    dades = doc.to_dict()
    matricula_db = dades.get("matricula", "").replace(" ", "").upper()
    
    # Ex: "0987CV" == començar igual que "0987CVB"
    if net_transcript and matricula_db.startswith(net_transcript):
        coincidencia = {
            "status": "trobada",
            "transcripcio": transcript,
            "matricula_detectada": net_transcript,
            "dades": dades
        }
        break


if coincidencia:
    print(json.dumps(coincidencia, ensure_ascii=False, indent=2))
else:
    print(json.dumps({
        "status": "no_trobada",
        "transcripcio": transcript,
        "matricula_detectada": net_transcript
    }, ensure_ascii=False, indent=2))
