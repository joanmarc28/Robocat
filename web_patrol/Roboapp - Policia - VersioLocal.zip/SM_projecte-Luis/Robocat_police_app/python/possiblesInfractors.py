import json
from google.cloud import firestore
from google.oauth2 import service_account
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")
credentials = service_account.Credentials.from_service_account_file(key_path)

# Connexió a Firestore
db = firestore.Client(credentials=credentials)

# Llegeix documents de la col·lecció "infractors"
infractors_ref = db.collection(u'possibles_infractors')
docs = infractors_ref.stream()

# Converteix documents a llista de dicts
resultat = []
for doc in docs:
    if doc.exists:
        dades = doc.to_dict()
        resultat.append({
            "matricula": dades.get("matricules", ""),
            "timestamp": dades.get("timestamp", ""),
            "infraccio": dades.get("infraccio", ""),
        })

# Retorna en format JSON
print(json.dumps(resultat))
