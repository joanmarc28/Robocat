import sys
import json
from google.cloud import firestore
from google.oauth2 import service_account
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")
credentials = service_account.Credentials.from_service_account_file(key_path)
db = firestore.Client(credentials=credentials)

try:
    entrada = json.loads(sys.argv[1])
    dni = entrada.get("dni")
    data = entrada.get("data")

    if not dni or not data:
        print(json.dumps({"status": "error", "missatge": "Falten camps"}))
        exit()

    col_ref = db.collection(u'infractors')
    query = col_ref.where("dni", "==", dni).where("data", "==", data)
    docs = query.stream()

    eliminats = 0
    for doc in docs:
        doc.reference.delete()
        eliminats += 1

    if eliminats > 0:
        print(json.dumps({"status": "ok"}))
    else:
        print(json.dumps({"status": "error", "missatge": "No s’ha trobat el document"}))

except Exception as e:
    print(json.dumps({"status": "error", "missatge": str(e)}))
