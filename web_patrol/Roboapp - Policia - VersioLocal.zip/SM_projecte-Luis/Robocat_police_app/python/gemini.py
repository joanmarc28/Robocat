import sys
import json
import cv2
import google.generativeai as genai
import os
# Comprova que s'ha passat un fitxer com argument
if len(sys.argv) < 2:
    print(json.dumps({"error": "No s’ha especificat cap imatge"}))
    sys.exit(1)

# Ruta de la imatge rebuda
ruta_imatge = sys.argv[1]

# Configura l’API de Gemini
genai.configure(api_key="AIzaSyAVpip8MqezRigYzoVXIty8-Ks_xowjorU")

# Carrega el model
model = genai.GenerativeModel("gemini-1.5-flash")

# Llegeix la imatge amb OpenCV
img = cv2.imread(ruta_imatge)
if img is None:
    print(json.dumps({"error": f"No s’ha pogut llegir la imatge a {ruta_imatge}"}))
    sys.exit(1)

# Codifica la imatge
_, img_encoded = cv2.imencode('.jpg', img)
image_bytes = img_encoded.tobytes()

# Prompt per al model
prompt = (
    "Analitza aquesta imatge d’un vídeo. "
    "Detecta matrícules de cotxes, identifica vehicles i descriu qualsevol infracció de trànsit. "
    "Retorna un JSON amb 'matricules' (llista) i 'infraccio' (comença amb si, no o possible i després una descripció breu sense accents)."
)

# Fa la crida al model
try:
    response = model.generate_content([
        {"mime_type": "image/jpeg", "data": image_bytes},
        {"text": prompt}
    ])
    print(response.text)  # Aquí és on el PHP captura la resposta
except Exception as e:
    print(json.dumps({"error": str(e)}))
    sys.exit(1)

raw_text = response.text

# Troba l'índex de l'inici i final del JSON
start = raw_text.find('{')
end = raw_text.rfind('}')

if start != -1 and end != -1:
    json_str = raw_text[start:end+1]
    try:
        resultat_json = json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"Error decodificant JSON: {e}")
        resultat_json = None
else:
    print("No s'ha trobat un JSON vàlid a la resposta.")
    resultat_json = None

resultat_path = "/tmp/resultat.json"
#resultat_path = os.path.join(os.path.dirname(__file__), 'resultat.json')

try:
    resultat_json = json.loads(json_str)
    with open(resultat_path, 'w', encoding='utf-8') as f:
        json.dump(json_str, f, ensure_ascii=False, indent=2)
    #print(json.dumps(resultat_json))  # si vols també veure-ho per terminal
except Exception as e:
    print(json.dumps({"error": f"Error al desar el JSON: {str(e)}"}))
