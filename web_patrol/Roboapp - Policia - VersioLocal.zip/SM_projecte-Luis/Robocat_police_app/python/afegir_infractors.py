import sys
import json
from google.cloud import firestore
from google.oauth2 import service_account
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
key_path = os.path.join(BASE_DIR, "..", "keys", "DB", "projecte-sm-3dcdbcb49f78.json")
credentials = service_account.Credentials.from_service_account_file(key_path)
db = firestore.Client(credentials=credentials)

try:
    dades = json.loads(sys.argv[1])
    doc_ref = db.collection('infractors').document()
    doc_ref.set(dades)
    print(json.dumps({"status": "ok"}))
except Exception as e:
    print(json.dumps({"status": "error", "missatge": str(e)}))
