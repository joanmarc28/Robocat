<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robocat</title>
    <link rel="stylesheet" href="../css/dblist_style.css"> 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
    <script src="js/script.js" defer></script> 
</head>
<body>
    <header>
        <?php include_once __DIR__.'/../controllers/header_controller.php'; ?>
    </header>

    <section class="dblist">
        <?php 
            include_once __DIR__.'/../controllers/infractors_controller.php'; 
        ?>
    </section>
        <section class="dblist">
        <?php 
            include_once __DIR__.'/../controllers/possibles_infraccions_controller.php'; 
        ?>
    </section>
</body>
</html>
