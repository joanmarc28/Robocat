<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inici de sessió</title>
    <link rel="stylesheet" href="../css/login_style.css"> 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
    <script src="js/script.js" defer></script> 
</head>
<body>
    
    <section class="header">
        <?php 
            include_once __DIR__.'/../controllers/header_controller.php'; 
        ?>
    </section>

    <section class="formulari">
        <?php 
            include_once __DIR__.'/../controllers/login_controller.php'; 
        ?>
    </section>

</body>
</html>