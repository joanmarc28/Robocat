<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planificador de ruta</title>
    <link rel="stylesheet" href="../css/map_style.css"> 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
    <script src="js/script.js" defer></script> 
</head>
<body>

    <header>
        <?php include_once __DIR__.'/../controllers/header_controller.php'; ?>
    </header>


    <section class="map">
        <?php 
            include_once __DIR__.'/../controllers/routing_controller.php'; 
        ?>
    </section>

</body>
</html>