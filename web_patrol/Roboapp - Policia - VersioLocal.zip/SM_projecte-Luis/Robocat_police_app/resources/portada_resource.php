<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Robocat</title>
    <link rel="stylesheet" href="../css/portada_style.css">
</head>
<body>
<?php 
    include_once __DIR__.'/../controllers/portada_controller.php'; 
?>
</body>
</html>
