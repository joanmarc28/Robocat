<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$accio = $_GET['opcio'] ?? NULL;

switch ($accio) {

    case 'login':
        include_once __DIR__."/resources/login_resource.php"; 
        break;
    case 'signup':
        include_once __DIR__."/resources/register_resource.php"; 
        break;
    case 'routing':
        include_once __DIR__."/resources/routing_resource.php"; 
        break;
    case 'stt':
        include_once __DIR__."/resources/stt_resource.php"; 
        break;
    case 'gemini':
        include_once __DIR__."/resources/gemini_resource.php"; 
        break;
    case 'mode':
        include_once __DIR__."/resources/mode_resource.php"; 
        break;
    case 'infractors':
        include_once __DIR__."/resources/infractors_resource.php"; 
        break;
    case 'afegir-infraccio':
        include_once __DIR__."/resources/afegir_infractors_resource.php"; 
        break;
    case 'home':
        include_once __DIR__."/resources/home_resource.php"; 
        break;
    case 'portada':
        include __DIR__."/resources/portada_resource.php";
        break;
    
    default:
        include __DIR__."/resources/portada_resource.php";
        break;
}
?>

